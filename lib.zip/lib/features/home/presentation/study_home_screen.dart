import 'dart:async';

import 'package:flutter/material.dart';

/// Opens the redesigned Today dashboard from surfaces that still use the
/// previous top-level helper API.
Future<void> showTodayBriefingModal({
  required BuildContext context,
  Object? database,
  Object? planningRepository,
  Object? noteRepository,
  VoidCallback? onOpenTodo,
}) {
  return showDialog<void>(
    context: context,
    builder: (context) => Dialog(
      insetPadding: const EdgeInsets.all(24),
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: SizedBox(
        width: 1240,
        height: 760,
        child: StudyHomeScreen(
          database: database,
          planningRepository: planningRepository,
        ),
      ),
    ),
  );
}

/// Temporary calendar modal kept for compatibility with Library/PDF reader
/// shortcuts until the full calendar surface is wired into the redesigned
/// Today system.
Future<void> showStudyCalendarModal({
  required BuildContext context,
  Object? database,
  Object? planningRepository,
  Object? noteRepository,
  VoidCallback? onOpenTodo,
}) {
  return showDialog<void>(
    context: context,
    builder: (context) => const Dialog(
      insetPadding: EdgeInsets.all(32),
      clipBehavior: Clip.antiAlias,
      child: _StudyCalendarModalFallback(),
    ),
  );
}

/// Visual baseline for the redesigned Today page.
///
/// This screen intentionally keeps the data local/static for this first pass so
/// the product shape can be evaluated in the running app before we connect the
/// panels to the planning repository, library, calendar, and project systems.
class StudyHomeScreen extends StatefulWidget {
  const StudyHomeScreen({
    super.key,
    this.database,
    this.planningRepository,
  });

  /// Kept as compatibility inputs because app/app.dart still constructs this
  /// screen with the real database/repository. This first visual pass does not
  /// consume them yet.
  final Object? database;
  final Object? planningRepository;

  @override
  State<StudyHomeScreen> createState() => _StudyHomeScreenState();
}

class _StudyHomeScreenState extends State<StudyHomeScreen> {
  late DateTime _now;
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _clockTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (!mounted) return;
      setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _TodayColors.canvas,
      body: SafeArea(
        child: Column(
          children: [
            const _TodayTopNavigation(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 18, 24, 28),
                child: _TodayDashboard(now: _now),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StudyCalendarModalFallback extends StatelessWidget {
  const _StudyCalendarModalFallback();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 720,
      height: 520,
      child: Scaffold(
        backgroundColor: _TodayColors.canvas,
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const _SectionIcon(icon: Icons.calendar_month_rounded),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'Calendar',
                      style: _TodayText.sectionTitle,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Close',
                    onPressed: () => Navigator.of(context).maybePop(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Expanded(
                child: _SurfaceCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Calendar surface placeholder',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: _TodayColors.ink,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'The Today redesign keeps this shortcut compiling while the full calendar view is reconnected.',
                        style: _TodayText.muted,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TodayDashboard extends StatelessWidget {
  const _TodayDashboard({required this.now});

  final DateTime now;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 1050;
        final topRow = wide
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(width: 300, child: _TodayDateCard(now: now)),
                  const SizedBox(width: 18),
                  Expanded(child: _WeekOverviewCard(now: now)),
                ],
              )
            : Column(
                children: [
                  _TodayDateCard(now: now),
                  const SizedBox(height: 16),
                  _WeekOverviewCard(now: now),
                ],
              );

        final mainContent = wide
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Expanded(
                    flex: 7,
                    child: _TodayMainColumn(),
                  ),
                  SizedBox(width: 18),
                  SizedBox(
                    width: 360,
                    child: _TodaySideColumn(),
                  ),
                ],
              )
            : const Column(
                children: [
                  _TodayMainColumn(),
                  SizedBox(height: 16),
                  _TodaySideColumn(),
                ],
              );

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            topRow,
            const SizedBox(height: 18),
            mainContent,
          ],
        );
      },
    );
  }
}

class _TodayTopNavigation extends StatelessWidget {
  const _TodayTopNavigation();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      padding: const EdgeInsets.symmetric(horizontal: 22),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: _TodayColors.border),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: _TodayColors.softPurple,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.grid_view_rounded,
              size: 17,
              color: _TodayColors.accent,
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'Notedesk',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: _TodayColors.ink,
              letterSpacing: -.2,
            ),
          ),
          const SizedBox(width: 16),
          Container(
            width: 1,
            height: 24,
            color: _TodayColors.border,
          ),
          const SizedBox(width: 16),
          const Text(
            'Today',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: _TodayColors.ink,
            ),
          ),
          const Spacer(),
          const _TopNavAction(icon: Icons.route_outlined, label: 'Future map'),
          const _TopNavAction(icon: Icons.notes_rounded, label: 'Writer lab'),
          const _TopNavAction(icon: Icons.calendar_month_outlined, label: 'Calendar'),
          const SizedBox(width: 8),
          _NavPillButton(
            icon: Icons.add_rounded,
            label: 'Plan',
            onTap: () => debugPrint('Plan tapped'),
          ),
          const SizedBox(width: 8),
          _NavPillButton(
            icon: Icons.folder_outlined,
            label: 'Library',
            filled: false,
            onTap: () => debugPrint('Library tapped'),
          ),
          const SizedBox(width: 12),
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: _TodayColors.softPurple,
              shape: BoxShape.circle,
            ),
            child: const Text(
              'J',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: _TodayColors.accent,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopNavAction extends StatelessWidget {
  const _TopNavAction({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: _TodayColors.accent),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _TodayColors.accent,
            ),
          ),
        ],
      ),
    );
  }
}

class _NavPillButton extends StatelessWidget {
  const _NavPillButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.filled = true,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        height: 32,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: filled ? _TodayColors.softPurple : Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: _TodayColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16, color: _TodayColors.accent),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: _TodayColors.accent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayMainColumn extends StatelessWidget {
  const _TodayMainColumn();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _TodayTasksPanel(),
        SizedBox(height: 16),
        _PlanningCanvasPanel(),
      ],
    );
  }
}

class _TodaySideColumn extends StatelessWidget {
  const _TodaySideColumn();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _QuickAccessPanel(),
        SizedBox(height: 16),
        _ActiveProjectsPanel(),
      ],
    );
  }
}

class _TodayDateCard extends StatelessWidget {
  const _TodayDateCard({required this.now});

  final DateTime now;

  @override
  Widget build(BuildContext context) {
    final day = now.day.toString();
    final month = _DateText.month(now.month);
    final time = _DateText.time(now);
    final weekday = _DateText.weekday(now.weekday);

    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(28, 26, 28, 24),
      child: SizedBox(
        height: 116,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    day,
                    style: const TextStyle(
                      fontSize: 64,
                      height: .86,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -3,
                      color: _TodayColors.ink,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    month,
                    style: const TextStyle(
                      fontSize: 27,
                      height: 1,
                      fontWeight: FontWeight.w900,
                      color: _TodayColors.accent,
                      letterSpacing: -.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 18),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  time,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: _TodayColors.ink,
                    letterSpacing: -.3,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  weekday,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: _TodayColors.inkMuted,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _WeekOverviewCard extends StatelessWidget {
  const _WeekOverviewCard({required this.now});

  final DateTime now;

  static const _taskCounts = [3, 3, 4, 3, 5, 2, 2];
  static const _doneCounts = [2, 1, 1, 0, 2, 0, 0];

  @override
  Widget build(BuildContext context) {
    final startOfWeek = DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: now.weekday - 1));

    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
      child: SizedBox(
        height: 136,
        child: Column(
          children: [
            Row(
              children: [
                const _SectionIcon(icon: Icons.calendar_month_outlined),
                const SizedBox(width: 10),
                const Text(
                  'Week overview',
                  style: _TodayText.sectionTitle,
                ),
                const Spacer(),
                _SmallRoundButton(
                  icon: Icons.chevron_left_rounded,
                  onTap: () => debugPrint('Previous week tapped'),
                ),
                const SizedBox(width: 8),
                Container(
                  height: 32,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _TodayColors.softPurple,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: _TodayColors.border),
                  ),
                  child: const Text(
                    'This week',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: _TodayColors.accent,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                _SmallRoundButton(
                  icon: Icons.chevron_right_rounded,
                  onTap: () => debugPrint('Next week tapped'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _TodayColors.border),
                ),
                clipBehavior: Clip.antiAlias,
                child: Row(
                  children: List.generate(7, (index) {
                    final date = startOfWeek.add(Duration(days: index));
                    final active = _DateText.sameDate(date, now);
                    return Expanded(
                      child: _WeekDayTile(
                        date: date,
                        active: active,
                        tasks: _taskCounts[index],
                        done: _doneCounts[index],
                      ),
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WeekDayTile extends StatelessWidget {
  const _WeekDayTile({
    required this.date,
    required this.active,
    required this.tasks,
    required this.done,
  });

  final DateTime date;
  final bool active;
  final int tasks;
  final int done;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: active ? _TodayColors.activeWeekTile : Colors.transparent,
        border: Border(
          right: BorderSide(
            color: date.weekday == DateTime.sunday
                ? Colors.transparent
                : _TodayColors.border,
          ),
        ),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxHeight < 82;
          final weekdayStyle = TextStyle(
            fontSize: compact ? 11 : 13,
            height: 1,
            fontWeight: FontWeight.w900,
            color: active ? _TodayColors.ink : _TodayColors.inkMuted,
          );
          final dayStyle = TextStyle(
            fontSize: compact ? 13 : 15,
            height: 1,
            fontWeight: FontWeight.w900,
            color: _TodayColors.ink,
          );
          final taskStyle = TextStyle(
            fontSize: compact ? 10 : 12,
            height: 1,
            fontWeight: FontWeight.w800,
            color: _TodayColors.ink,
          );
          final doneStyle = TextStyle(
            fontSize: compact ? 10 : 11,
            height: 1,
            color: _TodayColors.inkFaint,
            fontWeight: FontWeight.w700,
          );

          return Padding(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 8 : 10,
              vertical: compact ? 5 : 8,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  _DateText.shortWeekday(date.weekday),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: weekdayStyle,
                ),
                SizedBox(height: compact ? 2 : 3),
                Text(
                  date.day.toString(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: dayStyle,
                ),
                SizedBox(height: compact ? 5 : 8),
                Text(
                  '$tasks tasks',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: taskStyle,
                ),
                SizedBox(height: compact ? 3 : 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: compact ? 4 : 5,
                      height: compact ? 4 : 5,
                      decoration: const BoxDecoration(
                        color: _TodayColors.doneGreen,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Flexible(
                      child: Text(
                        '$done done',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: doneStyle,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _TodayTasksPanel extends StatelessWidget {
  const _TodayTasksPanel();

  static const tasks = [
    _TaskItem('Review Chapter 1 notes', 'Study'),
    _TaskItem('Draft literature review', 'Study'),
    _TaskItem('Email supervisor update', 'Admin'),
    _TaskItem('Prepare presentation slides', 'Work'),
  ];

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      child: Column(
        children: [
          Row(
            children: [
              const _SectionIcon(icon: Icons.checklist_rounded),
              const SizedBox(width: 10),
              const Text("Today's tasks", style: _TodayText.sectionTitle),
              const Spacer(),
              _SmallRoundButton(
                icon: Icons.filter_alt_outlined,
                onTap: () => debugPrint('Filter tasks tapped'),
              ),
              const SizedBox(width: 8),
              _SmallRoundButton(
                icon: Icons.more_horiz_rounded,
                onTap: () => debugPrint('Task menu tapped'),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _TodayColors.border),
            ),
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 760;
                final taskList = Column(
                  children: [
                    for (final task in tasks) _TaskRow(task: task),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () => debugPrint('Add task tapped'),
                        icon: const Icon(Icons.add_rounded, size: 18),
                        label: const Text('Add task'),
                        style: TextButton.styleFrom(
                          foregroundColor: _TodayColors.accent,
                          textStyle: const TextStyle(
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                  ],
                );

                if (compact) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      taskList,
                      const Divider(height: 24, color: _TodayColors.border),
                      const _RelatedFilePanel(),
                    ],
                  );
                }

                return IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(flex: 6, child: taskList),
                      const VerticalDivider(
                        width: 28,
                        thickness: 1,
                        color: _TodayColors.border,
                      ),
                      const Expanded(flex: 4, child: _RelatedFilePanel()),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskRow extends StatelessWidget {
  const _TaskRow({required this.task});

  final _TaskItem task;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 38,
      child: Row(
        children: [
          Container(
            width: 17,
            height: 17,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _TodayColors.checkbox),
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              task.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _TodayColors.ink,
              ),
            ),
          ),
          const SizedBox(width: 12),
          _PillLabel(label: task.tag),
        ],
      ),
    );
  }
}

class _RelatedFilePanel extends StatelessWidget {
  const _RelatedFilePanel();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: const [
              Text(
                'Open related file',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: _TodayColors.ink,
                ),
              ),
              Spacer(),
              Icon(Icons.arrow_forward_rounded, color: _TodayColors.ink, size: 22),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _TodayColors.cardTint,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _TodayColors.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: _TodayColors.softPurple,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.description_outlined,
                    color: _TodayColors.accent,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bahr Trilogy - pp. 1–9.pdf',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: _TodayColors.ink,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'PDF • 2.4 MB • Modified 2h ago',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _TodayColors.inkFaint,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          OutlinedButton(
            onPressed: () => debugPrint('Browse library tapped'),
            style: OutlinedButton.styleFrom(
              foregroundColor: _TodayColors.accent,
              side: const BorderSide(color: _TodayColors.borderStrong),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              textStyle: const TextStyle(fontWeight: FontWeight.w900),
            ),
            child: const Text('Browse library'),
          ),
        ],
      ),
    );
  }
}

class _PlanningCanvasPanel extends StatelessWidget {
  const _PlanningCanvasPanel();

  static const blocks = [
    _PlanBlock('Morning', 'Bahr Trilogy · pp. 1–9'),
    _PlanBlock('Afternoon', 'Shantaram · ch. 1'),
    _PlanBlock('Evening', 'Study materials · pp. 1–4'),
    _PlanBlock('Unscheduled', '4 task candidates'),
  ];

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      child: Column(
        children: [
          Row(
            children: [
              const _SectionIcon(icon: Icons.dashboard_customize_outlined),
              const SizedBox(width: 10),
              const Text('Planning canvas', style: _TodayText.sectionTitle),
              const Spacer(),
              TextButton.icon(
                onPressed: () => debugPrint('Calendar from planning canvas tapped'),
                icon: const Icon(Icons.open_in_new_rounded, size: 16),
                label: const Text('Calendar'),
                style: TextButton.styleFrom(
                  foregroundColor: _TodayColors.accent,
                  textStyle: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _TodayColors.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                for (var i = 0; i < blocks.length; i++)
                  _PlanningCanvasRow(
                    block: blocks[i],
                    last: i == blocks.length - 1,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlanningCanvasRow extends StatelessWidget {
  const _PlanningCanvasRow({required this.block, required this.last});

  final _PlanBlock block;
  final bool last;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 56),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: last ? Colors.transparent : _TodayColors.border,
          ),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 105,
            child: Text(
              block.label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: _TodayColors.ink,
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: 32,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: _TodayColors.cardTint,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: _TodayColors.border),
              ),
              child: Text(
                block.value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: _TodayColors.inkMuted,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickAccessPanel extends StatelessWidget {
  const _QuickAccessPanel();

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      child: Column(
        children: const [
          _PanelHeader(icon: Icons.bolt_rounded, title: 'Quick access'),
          SizedBox(height: 14),
          _QuickAccessTile(
            icon: Icons.menu_book_outlined,
            title: 'Library',
            subtitle: 'Open PDFs, EPUBs, and notes',
          ),
          SizedBox(height: 9),
          _QuickAccessTile(
            icon: Icons.calendar_month_outlined,
            title: 'Calendar',
            subtitle: 'Review exact requirements',
          ),
          SizedBox(height: 9),
          _QuickAccessTile(
            icon: Icons.checklist_rounded,
            title: 'Create plan',
            subtitle: 'Turn work into daily steps',
          ),
          SizedBox(height: 9),
          _QuickAccessTile(
            icon: Icons.grid_view_rounded,
            title: 'Create project',
            subtitle: 'Start a new work stream',
          ),
        ],
      ),
    );
  }
}

class _QuickAccessTile extends StatelessWidget {
  const _QuickAccessTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => debugPrint('$title tapped'),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: _TodayColors.cardTint,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _TodayColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: _TodayColors.softPurple,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: _TodayColors.accent, size: 19),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: _TodayColors.ink,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: _TodayColors.inkFaint,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            const Icon(Icons.arrow_forward_rounded, color: _TodayColors.ink, size: 19),
          ],
        ),
      ),
    );
  }
}

class _ActiveProjectsPanel extends StatelessWidget {
  const _ActiveProjectsPanel();

  static const projects = [
    _ProjectItem('Jobsök 2026', '4 required today • 4 active plans', .60),
    _ProjectItem('Research Papers', '3 required today • 2 active plans', .40),
    _ProjectItem('Personal Development', '1 required today • 1 active plan', .20),
  ];

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
      child: Column(
        children: [
          Row(
            children: [
              const _SectionIcon(icon: Icons.work_outline_rounded),
              const SizedBox(width: 10),
              const Expanded(child: Text('Active projects', style: _TodayText.sectionTitle)),
              TextButton(
                onPressed: () => debugPrint('View all projects tapped'),
                style: TextButton.styleFrom(
                  foregroundColor: _TodayColors.accent,
                  textStyle: const TextStyle(fontWeight: FontWeight.w900),
                ),
                child: const Text('View all'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _TodayColors.border),
            ),
            child: Column(
              children: [
                for (var i = 0; i < projects.length; i++)
                  _ProjectRow(project: projects[i], last: i == projects.length - 1),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => debugPrint('Create project tapped'),
              icon: const Icon(Icons.add_rounded, size: 18),
              label: const Text('Create project'),
              style: OutlinedButton.styleFrom(
                foregroundColor: _TodayColors.accent,
                side: const BorderSide(color: _TodayColors.borderStrong),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999),
                ),
                textStyle: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProjectRow extends StatelessWidget {
  const _ProjectRow({required this.project, required this.last});

  final _ProjectItem project;
  final bool last;

  @override
  Widget build(BuildContext context) {
    final percent = (project.progress * 100).round();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: last ? Colors.transparent : _TodayColors.border,
          ),
        ),
      ),
      child: Row(
        children: [
          const Icon(Icons.folder_rounded, color: _TodayColors.accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  project.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: _TodayColors.ink,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  project.subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: _TodayColors.inkFaint,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 86,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: project.progress,
                minHeight: 4,
                color: _TodayColors.accent,
                backgroundColor: _TodayColors.border,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '$percent%',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w900,
              color: _TodayColors.inkMuted,
            ),
          ),
        ],
      ),
    );
  }
}

class _PanelHeader extends StatelessWidget {
  const _PanelHeader({required this.icon, required this.title});

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _SectionIcon(icon: icon),
        const SizedBox(width: 10),
        Expanded(child: Text(title, style: _TodayText.sectionTitle)),
      ],
    );
  }
}

class _SurfaceCard extends StatelessWidget {
  const _SurfaceCard({required this.child, this.padding});

  final Widget child;
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.92),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _TodayColors.borderStrong),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F392D69),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _SectionIcon extends StatelessWidget {
  const _SectionIcon({required this.icon});

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        color: _TodayColors.softPurple,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Icon(icon, size: 16, color: _TodayColors.accent),
    );
  }
}

class _SmallRoundButton extends StatelessWidget {
  const _SmallRoundButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: _TodayColors.cardTint,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: _TodayColors.border),
        ),
        child: Icon(icon, size: 18, color: _TodayColors.accent),
      ),
    );
  }
}

class _PillLabel extends StatelessWidget {
  const _PillLabel({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: _TodayColors.softPurple,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: _TodayColors.inkMuted,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _TaskItem {
  const _TaskItem(this.title, this.tag);

  final String title;
  final String tag;
}

class _PlanBlock {
  const _PlanBlock(this.label, this.value);

  final String label;
  final String value;
}

class _ProjectItem {
  const _ProjectItem(this.title, this.subtitle, this.progress);

  final String title;
  final String subtitle;
  final double progress;
}

class _DateText {
  const _DateText._();

  static String month(int month) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return months[month - 1];
  }

  static String weekday(int weekday) {
    const days = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];
    return days[weekday - 1];
  }

  static String shortWeekday(int weekday) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days[weekday - 1];
  }

  static String time(DateTime dateTime) {
    final hour = dateTime.hour.toString().padLeft(2, '0');
    final minute = dateTime.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  static bool sameDate(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}

class _TodayText {
  const _TodayText._();

  static const sectionTitle = TextStyle(
    fontSize: 17,
    fontWeight: FontWeight.w900,
    letterSpacing: -.2,
    color: _TodayColors.ink,
  );

  static const muted = TextStyle(
    fontSize: 13,
    height: 1.35,
    fontWeight: FontWeight.w600,
    color: _TodayColors.inkMuted,
  );
}

class _TodayColors {
  const _TodayColors._();

  static const canvas = Color(0xFFFCFAFF);
  static const ink = Color(0xFF19172F);
  static const inkMuted = Color(0xFF504E73);
  static const inkFaint = Color(0xFF817E9B);
  static const accent = Color(0xFF5551B8);
  static const border = Color(0xFFE5E0F1);
  static const borderStrong = Color(0xFFD8D1EC);
  static const softPurple = Color(0xFFF0EDFF);
  static const cardTint = Color(0xFFFBF9FF);
  static const activeWeekTile = Color(0xFFF0EBFF);
  static const doneGreen = Color(0xFF20B15A);
  static const checkbox = Color(0xFFB7B2CC);
}
